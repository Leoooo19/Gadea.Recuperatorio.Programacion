
package excepciones;


public class EspectaculoDuplicadoException extends RuntimeException {
    public EspectaculoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}