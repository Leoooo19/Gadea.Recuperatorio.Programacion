package model;


import interfaces.Calificable;
import interfaces.Transmitible;
import java.time.LocalDate;
import java.util.List;

public class Concierto extends Espectaculo implements Transmitible, Calificable {
    private final Genero genero;
    private final List<String> artistas;

    public Concierto(String nombre, LocalDate fecha, int duracion, Genero genero, List<String> artistas) {
        super(nombre, fecha, duracion);
        this.genero = genero;
        this.artistas = artistas;
    }

    public Genero getGenero() {
        return genero;
    }

    public List<String> getArtistas() {
        return artistas;
    }

    @Override
    public void transmitir() {
        System.out.println("Se esta transmitiendo el concierto: " + getNombre());
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println("El concierto fue  calificado con: " + puntaje + " puntos");
    }

    @Override
    public String toString() {
        return super.toString() + " - Genero: " + genero + " - Artistas: " + artistas;
    }
}
