
package model;


public enum Genero {
    POP, 
    ROCK, 
    JAZZ
}