
package model;

public enum ClasificacionEdad {
    ATP, 
    MAYOR13, 
    MAYOR18
}