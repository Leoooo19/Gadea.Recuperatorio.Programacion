package model;

import java.time.LocalDate;

public abstract class Espectaculo {

    final String nombre;
    private final LocalDate fecha;
    private final int duracion;

    public Espectaculo(String nombre, LocalDate fecha, int duracion) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public String toString() {
        return nombre + " - " + fecha + " - " + duracion + " minutos";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Espectaculo otro = (Espectaculo) obj;
        return nombre.equalsIgnoreCase(otro.nombre) && fecha.equals(otro.fecha);
    }

    @Override
    public int hashCode() {
        return nombre.toLowerCase().hashCode() + fecha.hashCode();
    }
}
