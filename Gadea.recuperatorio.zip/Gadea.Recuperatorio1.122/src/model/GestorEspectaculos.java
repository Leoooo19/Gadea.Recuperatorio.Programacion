package model;

import excepciones.EspectaculoDuplicadoException;
import interfaces.Calificable;
import interfaces.Transmitible;
import java.util.ArrayList;
import java.util.List;

public class GestorEspectaculos {

    private final List<Espectaculo> espectaculos;

    public GestorEspectaculos() {
        espectaculos = new ArrayList<>();
    }

    public void validarEspectaculo(Espectaculo e) throws EspectaculoDuplicadoException {
        if (espectaculos.contains(e)) {
            throw new EspectaculoDuplicadoException("Ya existe un espectaculo con ese nombre y fecha: " + e);
        }
    }

    public void agregarEspectaculo(Espectaculo e) {
        try {
            validarEspectaculo(e);
            espectaculos.add(e);
        } catch (EspectaculoDuplicadoException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void mostrarEspectaculos() {
        for (Espectaculo e : espectaculos) {
            System.out.println(e);
        }
    }

    public void transmitirEventos() {
        for (Espectaculo e : espectaculos) {
            if (e instanceof Transmitible) {
                ((Transmitible) e).transmitir();
            } else {
                System.out.println("No se puede transmitir: " + e.getNombre());
            }
        }
    }

    public List<Concierto> filtrarPorGenero(Genero g) {
        List<Concierto> filtrados = new ArrayList<>();
        for (Espectaculo e : espectaculos) {
            if (e instanceof Concierto) {
                Concierto c = (Concierto) e;
                if (c.getGenero() == g) {
                    filtrados.add(c);
                    System.out.println(c);
                }
            }
        }
        return filtrados;
    }

    public void calificarEvento(String nombre, int puntaje) {
        boolean encontrado = false;
        for (Espectaculo e : espectaculos) {
            if (e.getNombre().equalsIgnoreCase(nombre)) {
                encontrado = true;
                if (e instanceof Calificable) {
                    ((Calificable) e).calificar(puntaje);
                } else {
                    System.out.println("El espectaculo no se puede calificar");
                }
                break;
            }
        }
        if (!encontrado) {
            System.out.println("Espectaculo no fue encontrado");
        }
    }
}
