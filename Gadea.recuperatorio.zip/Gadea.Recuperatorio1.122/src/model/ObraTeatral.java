
package model;

import interfaces.Calificable;
import java.time.LocalDate;

public class ObraTeatral extends Espectaculo implements Calificable {
    private ClasificacionEdad clasificacion;
    private String director;

    public ObraTeatral(String nombre, LocalDate fecha, int duracion, ClasificacionEdad clasificacion, String director) {
        super(nombre, fecha, duracion);
        this.clasificacion = clasificacion;
        this.director = director;
    }

    public ClasificacionEdad getClasificacion() {
        return clasificacion;
    }

    public String getDirector() {
        return director;
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println("La Obra teatral "+ nombre + " fue calificada con " + puntaje + " puntos.");
    }

    @Override
    public String toString() {
        return super.toString() + " - Clasificacion: " + clasificacion + " - Director: " + director;
    }
}