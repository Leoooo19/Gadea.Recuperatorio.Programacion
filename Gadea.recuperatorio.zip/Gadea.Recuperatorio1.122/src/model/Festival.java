
package model;


import interfaces.Transmitible;
import java.time.LocalDate;

public class Festival extends Espectaculo implements Transmitible {
    private int cantidadEscenarios;
    private boolean zonaCamping;

    public Festival(String nombre, LocalDate fecha, int duracion, int cantidadEscenarios, boolean zonaCamping) {
        super(nombre, fecha, duracion);
        this.cantidadEscenarios = cantidadEscenarios;
        this.zonaCamping = zonaCamping;
    }

    public int CantidadEscenarios() {
        return cantidadEscenarios;
    }

    public boolean tieneZonaCamping() {
        return zonaCamping;
    }

    @Override
    public void transmitir() {
        System.out.println("Se esta transmitiendo el festival: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + " - Escenarios: " + cantidadEscenarios + " - Camping: " + zonaCamping;
    }
}