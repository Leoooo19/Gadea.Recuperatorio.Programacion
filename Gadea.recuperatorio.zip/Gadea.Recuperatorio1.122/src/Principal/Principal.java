package Principal;

import java.time.LocalDate;
import java.util.List;
import model.ClasificacionEdad;
import model.Concierto;
import model.Festival;
import model.Genero;
import model.GestorEspectaculos;
import model.ObraTeatral;

public class Principal {

    public static void main(String[] args) {
        GestorEspectaculos gestor = new GestorEspectaculos();

        Concierto c1 = new Concierto("Megafestival", LocalDate.of(2025, 8, 23), 90, Genero.ROCK, List.of("Banda A"));
        Concierto c2 = new Concierto("Megafestival", LocalDate.of(2025, 8, 23), 100, Genero.ROCK, List.of("Banda B")); // duplicado
        ObraTeatral o1 = new ObraTeatral("Rabla", LocalDate.of(2025, 7, 17), 90, ClasificacionEdad.MAYOR13, "Director Lopez");
        Festival f1 = new Festival("Lollapaluza", LocalDate.of(2025, 7, 18), 500, 4, true);

        gestor.agregarEspectaculo(c1);
        gestor.agregarEspectaculo(c2);
        gestor.agregarEspectaculo(o1);
        gestor.agregarEspectaculo(f1);

        gestor.mostrarEspectaculos();
        gestor.transmitirEventos();
        gestor.filtrarPorGenero(Genero.ROCK);
        gestor.calificarEvento("Rabla", 6);
        gestor.calificarEvento("Lollapaluza", 9);
        gestor.calificarEvento("LosPalmeras", 5);
    }
}


