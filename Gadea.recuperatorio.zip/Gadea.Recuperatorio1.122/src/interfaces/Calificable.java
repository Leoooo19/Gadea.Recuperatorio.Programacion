
package interfaces;

public interface Calificable {
    void calificar(int puntaje);
}