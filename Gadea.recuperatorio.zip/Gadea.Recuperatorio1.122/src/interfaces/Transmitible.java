package interfaces;

public interface Transmitible {
    void transmitir();
}